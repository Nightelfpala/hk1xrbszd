
#ifndef APPMAIN_H_INCLUDED
#define APPMAIN_H_INCLUDED

#include <wx/wx.h>

class App : public wxApp
{
public:
	virtual bool OnInit();
};

#endif // APPMAIN_H_INCLUDED

